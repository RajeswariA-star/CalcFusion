// Function to show the selected page and hide the others
function showPage(page) {
  document.getElementById('home-page').style.display = page === 'home' ? 'block' : 'none';
  document.getElementById('basic-calculator').style.display = page === 'basic' ? 'block' : 'none';
  document.getElementById('scientific-calculator').style.display = page === 'scientific' ? 'block' : 'none';
  document.getElementById('history-page').style.display = page === 'history' ? 'block' : 'none';
}

// Basic Calculator Logic
const basicDisplay = document.getElementById('basic-display');
let basicCurrentInput = '';
let basicPreviousInput = '';
let basicOperator = '';

document.querySelector('#basic-calculator .calculator-keys').addEventListener('click', (event) => {
  if (!event.target.matches('button')) return; // Ensure only buttons trigger this event

  const value = event.target.getAttribute('value');
  if (!value) return;

  if (value === 'clear') {
    basicCurrentInput = '';
    basicPreviousInput = '';
    basicOperator = '';
    basicDisplay.textContent = '0';
  } else if (value === '=') {
    calculateBasic();
  } else if ('+-*/'.includes(value)) {
    basicOperator = value;
    basicPreviousInput = basicCurrentInput;
    basicCurrentInput = '';
  } else {
    basicCurrentInput += value;
    basicDisplay.textContent = basicCurrentInput;
  }
});

function calculateBasic() {
  let result;
  const prev = parseFloat(basicPreviousInput);
  const current = parseFloat(basicCurrentInput);

  switch (basicOperator) {
    case '+':
      result = prev + current;
      break;
    case '-':
      result = prev - current;
      break;
    case '*':
      result = prev * current;
      break;
    case '/':
      result = prev / current;
      break;
    default:
      result = current;
  }

  basicCurrentInput = result.toString();
  basicDisplay.textContent = result;

  // Add to history
  addToHistory(`${basicPreviousInput} ${basicOperator} ${basicCurrentInput} = ${result}`);
}

// Add a calculation to the history list
function addToHistory(item) {
  const historyList = document.getElementById('history-list');
  const listItem = document.createElement('li');
  listItem.textContent = item;
  historyList.appendChild(listItem);
}

// Scientific Calculator Logic
const sciDisplay = document.getElementById('sci-display');
let sciCurrentInput = '';
let sciOperator = '';

document.querySelector('#scientific-calculator .calculator-keys').addEventListener('click', (event) => {
  if (!event.target.matches('button')) return; // Ensure only buttons trigger this event

  const value = event.target.getAttribute('value');
  if (!value) return;

  if (value === 'clear') {
    sciCurrentInput = '';
    sciOperator = '';
    sciDisplay.textContent = '0';
  } else if (value === '=') {
    calculateScientific();
  } else if ('^'.includes(value)) {
    sciOperator = value;
    sciCurrentInput = sciDisplay.textContent;
    sciDisplay.textContent = '';
  } else if (['sin', 'cos', 'tan', 'log', 'sqrt', 'exp', 'π'].includes(value)) {
    performScientificOperation(value);
  } else {
    sciDisplay.textContent += value;
  }
});

function calculateScientific() {
  let result;
  const current = parseFloat(sciDisplay.textContent);

  switch (sciOperator) {
    case '^':
      result = Math.pow(parseFloat(sciCurrentInput), current);
      break;
    default:
      result = current;
  }

  sciDisplay.textContent = result;
  addToHistory(`${sciCurrentInput} ${sciOperator} ${current} = ${result}`);
}

function performScientificOperation(op) {
  let result;
  const current = parseFloat(sciDisplay.textContent);

  switch (op) {
    case 'sin':
      result = Math.sin(current);
      break;
    case 'cos':
      result = Math.cos(current);
      break;
    case 'tan':
      result = Math.tan(current);
      break;
    case 'log':
      result = Math.log10(current);
      break;
    case 'sqrt':
      result = Math.sqrt(current);
      break;
    case 'exp':
      result = Math.exp(current);
      break;
    case 'π':
      result = Math.PI;
      break;
    default:
      result = current;
  }

  sciDisplay.textContent = result;
  addToHistory(`${op}(${current}) = ${result}`);
}
